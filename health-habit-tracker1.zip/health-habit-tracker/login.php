<?php
session_start();
require 'db.php'; 

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        header("Location: index.php");
        exit();
    } else {
        $error = "Incorrect Email or Password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - HabitQuest</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;500;700&display=swap');

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Poppins', sans-serif;
            background: radial-gradient(circle at 10% 20%, #0b0f19 0%, #1a1b41 100%);
            color: #ffffff;
            height: 100vh;
            display: flex;
            flex-direction: column; /* Changed to accommodate footer */
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .glass-panel {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
            padding: 30px;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .neon-text-green { color: #00ffcc; text-shadow: 0 0 10px rgba(0, 255, 204, 0.6); font-family: 'Orbitron', sans-serif; }
        
        .logo { font-size: 28px; font-weight: 700; margin-bottom: 10px; }
        .subtitle { color: #a0aec0; font-size: 13px; margin-bottom: 30px; }

        .input-group { position: relative; margin-bottom: 20px; text-align: left; }
        .input-group i { position: absolute; left: 15px; top: 14px; color: #00d4ff; }
        
        input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(0, 212, 255, 0.2);
            border-radius: 12px;
            color: white;
            font-size: 16px;
            outline: none;
            transition: 0.3s;
        }
        
        input:focus {
            border-color: #00d4ff;
            box-shadow: 0 0 15px rgba(0, 212, 255, 0.3);
        }

        .btn-login {
            width: 100%;
            background: linear-gradient(45deg, #00d4ff, #00ffcc);
            border: none;
            padding: 14px;
            border-radius: 12px;
            color: #000;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            font-family: 'Orbitron', sans-serif;
            margin-top: 10px;
        }
        
        .btn-login:hover {
            transform: scale(1.02);
            box-shadow: 0 0 20px rgba(0, 255, 204, 0.6);
        }

        .links { 
            margin-top: 25px; 
            font-size: 13px; 
            color: #a0aec0;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .links a { color: #00d4ff; text-decoration: none; font-weight: bold; }
        
        .error-msg {
            background: rgba(255, 71, 87, 0.1);
            color: #ff4757;
            border: 1px solid rgba(255, 71, 87, 0.3);
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 13px;
            display: <?php echo $error ? 'block' : 'none'; ?>;
        }

        /* Team Footer */
        .footer {
            margin-top: 30px;
            font-family: 'Orbitron', sans-serif;
            font-size: 12px;
            color: #a0aec0;
            letter-spacing: 1px;
        }
        .team-name { color: #00ffcc; font-weight: bold; text-shadow: 0 0 8px rgba(0, 255, 204, 0.5); }
    </style>
</head>
<body>

    <div class="glass-panel">
        <div class="logo neon-text-green">HabitQuest</div>
        <p class="subtitle">Enter your details to start the quest</p>

        <div class="error-msg">
            <i class="fa-solid fa-circle-exclamation"></i> <?php echo $error; ?>
        </div>

        <form action="login.php" method="POST">
            <div class="input-group">
                <i class="fa-solid fa-envelope"></i>
                <input type="email" name="email" placeholder="Email Address" required>
            </div>
            
            <div class="input-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <button type="submit" class="btn-login">LOGIN</button>
        </form>

        <div class="links">
            <a href="forgot_password.php" style="font-weight: normal; color: #a0aec0;">Forgot Password?</a>
            <p>New User? <a href="signup.php">Sign Up</a></p>
        </div>
    </div>

    <div class="footer">
        Developed by <span class="team-name">Laxman Kuber & Team </span> 🚀
    </div>

</body>
</html>
<?php
session_start();
require 'db.php'; 

if(isset($_POST['task_id']) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $points_to_add = 10; 

    
    $stmt = $conn->prepare("UPDATE users SET total_coins = total_coins + ? WHERE id = ?");
    $stmt->bind_param("ii", $points_to_add, $user_id);
    
    if($stmt->execute()) {
        header("Location: dashboard.php?success=TaskCompleted");
        exit();
    } else {
        echo "Error updating points.";
    }
} else {
    header("Location: dashboard.php");
    exit();
}
?>
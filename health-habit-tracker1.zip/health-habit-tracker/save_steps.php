<?php
session_start();
require 'db.php';

if(isset($_POST['steps']) && isset($_SESSION['user_id'])) {
    $steps = (int)$_POST['steps'];
    $user_id = $_SESSION['user_id'];

    // Update steps in database
    $stmt = $conn->prepare("UPDATE users SET total_steps = ? WHERE id = ?");
    $stmt->bind_param("ii", $steps, $user_id);
    $stmt->execute();
    echo "Success";
}
?>
<?php
session_start();
require 'db.php';

if (!isset($_SESSION['temp_email'])) {
    header("Location: signup.php");
    exit();
}

$email = $_SESSION['temp_email'];
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_otp = $_POST['otp'];

    $stmt = $conn->prepare("SELECT id, name, otp FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && $user['otp'] == $entered_otp) {
        $update = $conn->prepare("UPDATE users SET is_verified = 1, otp = NULL WHERE email = ?");
        $update->bind_param("s", $email);
        $update->execute();

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        unset($_SESSION['temp_email']); 

        header("Location: index.php?success=WelcomePlayer");
        exit();
    } else {
        $error = "Invalid OTP! Please check your email again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify Identity - HabitQuest</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;500;700&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: radial-gradient(circle at 10% 20%, #0b0f19 0%, #1a1b41 100%); color: #ffffff; height: 100vh; display: flex; align-items: center; justify-content: center; }
        .glass-panel { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 20px; box-shadow: 0 4px 30px rgba(0, 0, 0, 0.5); padding: 40px; width: 100%; max-width: 400px; text-align: center; }
        .neon-text-orange { color: #ff9900; text-shadow: 0 0 10px rgba(255, 153, 0, 0.6); font-family: 'Orbitron', sans-serif; font-size: 28px; margin-bottom: 10px;}
        input { width: 100%; padding: 15px; text-align: center; font-size: 24px; letter-spacing: 5px; background: rgba(0, 0, 0, 0.3); border: 1px solid rgba(255, 153, 0, 0.3); border-radius: 10px; color: white; outline: none; font-family: 'Orbitron', sans-serif; margin-bottom: 20px;}
        input:focus { border-color: #ff9900; box-shadow: 0 0 15px rgba(255, 153, 0, 0.4); }
        .btn-verify { width: 100%; background: linear-gradient(45deg, #ff9900, #ff4757); border: none; padding: 15px; border-radius: 10px; color: white; font-weight: bold; font-size: 16px; cursor: pointer; transition: 0.3s; box-shadow: 0 0 15px rgba(255, 153, 0, 0.5); font-family: 'Orbitron', sans-serif; }
        .btn-verify:hover { transform: scale(1.05); box-shadow: 0 0 25px rgba(255, 153, 0, 0.8); }
        .error-msg { background: rgba(255, 71, 87, 0.1); color: #ff4757; border: 1px solid rgba(255, 71, 87, 0.3); padding: 10px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; display: <?php echo $error ? 'block' : 'none'; ?>; }
    </style>
</head>
<body>
    <div class="glass-panel">
        <div class="neon-text-orange"><i class="fa-solid fa-shield-halved"></i> Verify Email</div>
        <p style="color: #a0aec0; font-size: 14px; margin-bottom: 30px;">We sent a 6-digit code to <b><?php echo $email; ?></b></p>

        <div class="error-msg"><i class="fa-solid fa-triangle-exclamation"></i> <?php echo $error; ?></div>

        <form action="verify_otp.php" method="POST">
            <input type="text" name="otp" placeholder="XXXXXX" maxlength="6" required autocomplete="off">
            <button type="submit" class="btn-verify"><i class="fa-solid fa-check-double"></i> VERIFY CODE</button>
        </form>
    </div>
</body>
</html>
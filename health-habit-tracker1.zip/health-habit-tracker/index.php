<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<?php
session_start();
require 'db.php'; 

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT name, total_coins, current_streak, level, total_steps, last_step_update FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();

$today = date('Y-m-d');
$db_steps = isset($user_data['total_steps']) ? $user_data['total_steps'] : 0;

if(isset($user_data['last_step_update']) && $user_data['last_step_update'] != $today) {
    $update_reset = $conn->prepare("UPDATE users SET total_steps = 0, last_step_update = ? WHERE id = ?");
    $update_reset->bind_param("si", $today, $user_id);
    $update_reset->execute();
    $db_steps = 0;
}

$weekly_steps = [1500, 2800, 4200, 3100, 2000, 4800, $db_steps]; 

// Added 'id' in query to handle deletion
$habit_stmt = $conn->prepare("SELECT id, habit_name, habit_time FROM user_habits WHERE user_id = ?");
$habit_stmt->bind_param("i", $user_id);
$habit_stmt->execute();
$saved_habits = $habit_stmt->get_result();
$habit_count = $saved_habits->num_rows; 

$user_name = isset($user_data['name']) ? $user_data['name'] : "Player";
$coins = isset($user_data['total_coins']) ? $user_data['total_coins'] : 0;
$streak = isset($user_data['current_streak']) ? $user_data['current_streak'] : 0;
$level = isset($user_data['level']) ? $user_data['level'] : "Novice";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HabitQuest - Mega Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;500;700&display=swap');

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Poppins', sans-serif;
            background: radial-gradient(circle at 10% 20%, #0b0f19 0%, #1a1b41 100%);
            color: #ffffff;
            min-height: 100vh;
            display: flex;
            overflow-x: hidden;
            flex-direction: column; 
        }

        .glass { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 20px; box-shadow: 0 4px 30px rgba(0, 0, 0, 0.5); }
        .glass-inner { background: rgba(0, 0, 0, 0.2); border-radius: 12px; padding: 15px; border: 1px solid rgba(255,255,255,0.05); }

        .neon-text-green { color: #00ffcc; text-shadow: 0 0 10px rgba(0, 255, 204, 0.6); font-family: 'Orbitron', sans-serif; }
        .neon-text-orange { color: #ff9900; text-shadow: 0 0 10px rgba(255, 153, 0, 0.6); font-family: 'Orbitron', sans-serif; }
        .neon-text-blue { color: #00d4ff; text-shadow: 0 0 10px rgba(0, 212, 255, 0.6); font-family: 'Orbitron', sans-serif; }

        .sidebar { width: 260px; padding: 20px; display: flex; flex-direction: column; gap: 15px; z-index: 100; height: 100vh; position: fixed; left: 0; top: 0; transition: 0.3s; }
        .logo { font-size: 24px; font-weight: 700; text-align: center; margin-bottom: 20px; font-family: 'Orbitron'; color: #00ffcc; }
        .nav-item { padding: 12px 15px; border-radius: 12px; cursor: pointer; transition: 0.3s; display: flex; align-items: center; gap: 15px; font-weight: 500; color: #a0aec0; text-decoration: none; font-size: 14px;}
        .nav-item:hover, .nav-item.active { background: rgba(0, 212, 255, 0.1); color: #00d4ff; border-left: 4px solid #00d4ff; box-shadow: 0 0 15px rgba(0, 212, 255, 0.2); }

        .main-content { flex: 1; padding: 20px 30px; margin-left: 260px; overflow-y: auto; transition: 0.3s; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .avatar { width: 45px; height: 45px; border-radius: 50%; background: linear-gradient(45deg, #00d4ff, #00ffcc); display: center; justify-content: center; align-items: center; font-size: 18px; font-weight: bold; border: 2px solid #fff; box-shadow: 0 0 15px rgba(0, 255, 204, 0.5); }

        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 25px; }
        .stat-card { padding: 20px; display: flex; justify-content: space-between; align-items: center; transition: 0.3s; }
        .stat-card:hover { transform: translateY(-5px); border-color: #00d4ff; }
        .stat-info h2 { font-size: 24px; margin: 0; font-family: 'Orbitron'; }

        .bento-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
        .section-title { font-family: 'Orbitron', sans-serif; font-size: 18px; margin-bottom: 15px; color: #fff; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 8px; }

        .task-item { background: rgba(0, 0, 0, 0.3); border: 1px solid rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 12px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .btn-done { background: linear-gradient(45deg, #00b09b, #96c93d); border: none; padding: 10px 15px; border-radius: 8px; color: white; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn-delete { background: rgba(255, 71, 87, 0.1); color: #ff4757; border: 1px solid #ff4757; padding: 8px; border-radius: 8px; cursor: pointer; transition: 0.3s; margin-left: 5px;}
        .btn-delete:hover { background: #ff4757; color: white; }

        .video-container { position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 12px; border: 1px solid rgba(0, 212, 255, 0.3); margin-top: 15px;}
        .video-container iframe { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }

        #game-board { width: 100%; height: 150px; background: rgba(0,0,0,0.5); border-radius: 12px; position: relative; overflow: hidden; border: 1px dashed #ff9900; }
        #target { width: 25px; height: 25px; background: #ff4757; border-radius: 50%; position: absolute; cursor: crosshair; box-shadow: 0 0 10px #ff4757; }

        #memory-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; margin-top: 10px; }
        .memory-card { height: 45px; background: rgba(255, 255, 255, 0.1); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 20px; cursor: pointer; transition: 0.3s; border: 1px solid rgba(255,255,255,0.05); }
        .memory-card:hover { background: rgba(0, 212, 255, 0.2); }

        .meditation-box { text-align: center; padding: 40px 20px; background: rgba(0, 255, 204, 0.05); border-radius: 20px; border: 1px solid rgba(0, 255, 204, 0.1); margin-bottom: 20px; }
        .breath-circle { width: 150px; height: 150px; border: 6px solid #00ffcc; border-radius: 50%; margin: 0 auto; animation: breathe 8s infinite ease-in-out; display: flex; align-items: center; justify-content: center; font-size: 18px; font-family: 'Orbitron'; color: #00ffcc; text-shadow: 0 0 10px rgba(0, 255, 204, 0.5); box-shadow: 0 0 20px rgba(0, 255, 204, 0.2); }
        @keyframes breathe { 0%, 100% { transform: scale(1); opacity: 0.5; } 50% { transform: scale(1.4); opacity: 1; box-shadow: 0 0 40px rgba(0, 255, 204, 0.4); } }

        @media (max-width: 768px) {
            .sidebar { width: 100%; height: 75px; flex-direction: row; position: fixed; bottom: 0; left: 0; top: auto; padding: 10px; justify-content: space-around; border-radius: 20px 20px 0 0; background: rgba(11, 15, 25, 0.95); backdrop-filter: blur(10px); }
            .sidebar .logo, #alarmBtn span { display: none; } 
            .nav-item { flex-direction: column; gap: 5px; font-size: 10px; padding: 5px; border: none !important; width: auto; background: none !important; }
            .nav-item i { font-size: 20px; }
            .main-content { margin-left: 0; padding: 15px; padding-bottom: 100px; } 
            .bento-grid { grid-template-columns: 1fr; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
            .header h1 { font-size: 18px; }
            .footer { margin-left: 0 !important; margin-bottom: 85px; } 
        }

        .add-habit-form { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; }
        input[type="text"], input[type="time"] { background: rgba(0,0,0,0.4); border: 1px solid #00d4ff; padding: 10px; border-radius: 8px; color: white; outline: none; }
        .location-text { font-size: 11px; color: #00ffcc; margin-top: 5px; }

        .footer {
            margin-top: auto;
            padding: 20px;
            text-align: center;
            font-family: 'Orbitron', sans-serif;
            font-size: 12px;
            color: #a0aec0;
            margin-left: 260px; 
            letter-spacing: 1px;
        }
        .team-name { color: #00ffcc; font-weight: bold; text-shadow: 0 0 8px rgba(0, 255, 204, 0.5); }

        #alarmOverlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.95); z-index:10000; align-items:center; justify-content:center; text-align:center; }
    </style>
</head>
<body onclick="enableAudio()"> 

    <div id="alarmOverlay">
        <div class="glass" style="padding:40px; border: 2px solid #00ffcc; width: 90%; max-width: 400px;">
            <h1 class="neon-text-green" style="font-size: 30px;">⏰ QUEST TIME!</h1>
            <p id="alarmTaskName" style="font-size:24px; margin:20px 0; font-family:'Orbitron'; color: #00d4ff;"></p>
            <p style="color: #a0aec0; margin-bottom: 20px;">Hey <?php echo $user_name; ?>, finish your habit to stop the alarm!</p>
            <button class="btn-done" style="width:100%; padding: 20px; font-size:20px;" onclick="stopAlarm()">✅ I DID THIS!</button>
        </div>
    </div>

    <div class="sidebar glass">
        <div class="logo neon-text-green">HabitQuest</div>
        <a href="index.php" class="nav-item active"><i class="fa-solid fa-house"></i> <span>Home</span></a>
        <a href="ai_scan.php" class="nav-item"><i class="fa-solid fa-camera"></i> <span>Scan</span></a>
        <a href="zen_mode.php" class="nav-item"><i class="fa-solid fa-om"></i> <span>Zen</span></a>
        <a href="#games" class="nav-item"><i class="fa-solid fa-gamepad"></i> <span>Games</span></a>
        <button id="alarmBtn" class="nav-item" style="background:none; border:none; color: inherit; width: 100%;"><i class="fa-solid fa-bell"></i> <span>Enable Alarms</span></button>
        <a href="logout.php" class="nav-item" style="color: #ff4757;"><i class="fa-solid fa-power-off"></i> <span>Exit</span></a>
    </div>

    <div class="main-content">
        <div class="header">
            <div>
                <h1 style="font-size: 22px;">Hi, <span class="neon-text-blue"><?php echo htmlspecialchars($user_name); ?></span>! 🚀</h1>
                <p style="color: #a0aec0; font-size: 12px;">Tracking your live progress.</p>
                <div id="location-display" class="location-text">Detecting Location...</div>
            </div>
            <div class="avatar"><?php echo substr($user_name, 0, 1); ?></div>
        </div>

        <div class="meditation-box glass">
             <h3 class="section-title" style="border:none;"><i class="fa-solid fa-spa text-green-400"></i> Zen Meditation Mode</h3>
             <div class="breath-circle">BREATHE</div>
             <p style="font-size: 11px; color: #00ffcc; margin-top: 20px; letter-spacing: 2px;">INHALE ... EXHALE</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card glass" style="border-top: 3px solid #00ffcc;">
                <div class="stat-info"><h4>Health Coins</h4><h2 class="neon-text-green"><?php echo $coins; ?></h2></div>
                <div style="font-size: 30px;">🪙</div>
            </div>
            <div class="stat-card glass" style="border-top: 3px solid #ff9900;">
                <div class="stat-info"><h4>Streak</h4><h2 class="neon-text-orange"><?php echo $streak; ?> Days</h2></div>
                <div style="font-size: 30px;">🔥</div>
            </div>
            <div class="stat-card glass" style="border-top: 3px solid #00d4ff;">
                <div class="stat-info"><h4>Daily Steps</h4><h2 class="neon-text-blue" id="stepCounter"><?php echo $db_steps; ?></h2></div>
                <div style="font-size: 30px;"><i class="fa-solid fa-person-walking"></i></div>
            </div>
        </div>

        <div class="bento-grid">
            <div style="display: flex; flex-direction: column; gap: 20px;">
                
                <div class="glass" style="padding: 20px;">
                    <h3 class="section-title"><i class="fa-solid fa-chart-column text-blue-400"></i> 7-Day Activity Analysis</h3>
                    <canvas id="weeklyChart" height="150"></canvas>
                </div>

                <div class="glass" style="padding: 20px;">
                    <h3 class="section-title"><i class="fa-solid fa-trophy text-orange-400"></i> Daily Challenge</h3>
                    <div class="task-item" id="stepChallenge">
                        <div>
                            <h4>5,000 Steps Goal</h4>
                            <p id="challengeStatus" style="font-size: 10px; color:#a0aec0;">Reward: 4 Points | Progress: <?php echo $db_steps; ?>/5000</p>
                        </div>
                        <button class="btn-done" id="claimStepsBtn" style="opacity: 0.5; cursor: not-allowed;" disabled>Claim 4 Pts</button>
                    </div>
                </div>

                <div class="glass" style="padding: 20px;">
                    <h3 class="section-title"><i class="fa-solid fa-plus-circle text-blue-400"></i> Add New Habit</h3>
                    <div class="add-habit-form">
                        <input type="text" id="habitName" placeholder="Habit Name (Water, Food, etc.)">
                        <input type="time" id="habitTime">
                        <button class="btn-done" onclick="addNewHabitToDB()">Add Habit</button>
                    </div>
                    <div id="dynamic-habits" style="margin-top: 15px;">
                        <p style="font-size: 11px; color: #a0aec0; margin-bottom: 10px;">Daily Quests (4 Points each):</p>
                        <?php while($row = $saved_habits->fetch_assoc()): ?>
                            <div class="task-item habit-entry" data-time="<?php echo $row['habit_time']; ?>" data-name="<?php echo $row['habit_name']; ?>">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <i class="fa-solid fa-clock text-blue-400"></i>
                                    <div><h4><?php echo $row['habit_name']; ?></h4><p style="font-size: 10px; color:#a0aec0;">Time: <?php echo $row['habit_time']; ?></p></div>
                                </div>
                                <div style="display: flex; gap: 5px;">
                                    <button class="btn-done" onclick="claimHabitPoints('<?php echo $row['habit_name']; ?>', this)">Claim</button>
                                    <button class="btn-delete" onclick="deleteHabit(<?php echo $row['id']; ?>)"><i class="fa-solid fa-trash"></i></button>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="glass" style="padding: 20px;">
                        <h3 class="section-title" style="font-size: 14px;">Healthy Diet</h3>
                        <ul id="diet-list" style="list-style:none; font-size: 12px; color: #a0aec0;">
                            <li style="display:flex; justify-content:space-between; margin-bottom:5px;">Oats <span>300 kcal</span></li>
                        </ul>
                    </div>
                    <div class="glass" style="padding: 20px;">
                        <h3 class="section-title" style="font-size: 14px;">Guided Yoga</h3>
                        <div class="video-container"><iframe src="https://www.youtube.com/embed/sTANio_2E0Q?controls=0" frameborder="0" allowfullscreen></iframe></div>
                    </div>
                </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 20px;">
                <div class="glass" style="padding: 20px;">
                    <h3 class="section-title" style="font-size: 14px;">Quest Radar</h3>
                    <canvas id="questChart" height="200"></canvas>
                </div>

                <div class="glass" style="padding: 20px;" id="games">
                    <h3 class="section-title" style="font-size: 14px;">Mind Games Hub</h3>
                    <p style="font-size: 10px; color:#00ffcc;">1. Reaction Focus</p>
                    <div id="game-board" onclick="missedClick()"><div id="target" onclick="hitTarget(event)"></div></div>
                    <p id="score-display" style="text-align: center; margin-top: 5px; font-size:12px; color: #00ffcc;">Score: 0</p>
                    <hr style="opacity:0.1; margin: 10px 0;">
                    <p style="font-size: 10px; color:#00ffcc;">2. Memory Match</p>
                    <div id="memory-grid"></div>
                    <p id="memory-msg" style="text-align: center; font-size:10px; color:#a0aec0;">Find all pairs!</p>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">Developed by <span class="team-name">Laxman Kuber & Team </span> 🚀</div>

    <audio id="alarmSound" src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3" preload="auto" loop></audio>

    <script>
        // --- 1. RELIABLE AUDIO LOGIC (FORCE UNLOCK) ---
        let audioPermission = false;
        const alarmAudio = document.getElementById('alarmSound');

        function enableAudio() {
            if(!audioPermission) {
                alarmAudio.play().then(() => {
                    alarmAudio.pause();
                    audioPermission = true;
                    console.log("ALARM READY: Audio Unlocked!");
                }).catch(e => console.log("Unlock blocked"));
            }
        }

        function stopAlarm() {
            alarmAudio.pause();
            alarmAudio.currentTime = 0;
            document.getElementById('alarmOverlay').style.display = 'none';
        }

        // --- 2. DELETE HABIT AJAX ---
        
        function deleteHabit(habitId) {
            if(confirm("Remove this habit?")) {
                fetch('delete_habit.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `id=${habitId}`
                }).then(() => location.reload());
            }
        }

        // --- 3. REACTION GAME LOGIC ---
        let score = 0;
        const target = document.getElementById('target');
        const board = document.getElementById('game-board');
        function moveTarget() {
            if(!board || !target) return;
            target.style.left = Math.random() * (board.clientWidth - 30) + 'px';
            target.style.top = Math.random() * (board.clientHeight - 30) + 'px';
        }
        window.hitTarget = function(e) {
            e.stopPropagation(); score++;
            document.getElementById('score-display').innerText = "Score: " + score;
            moveTarget();
        };
        window.missedClick = function() { if(score > 0) score--; document.getElementById('score-display').innerText = "Score: " + score; };
        setInterval(moveTarget, 2000);

        // --- 4. MEMORY MATCH GAME LOGIC ---
        const emojis = ['🍎','🍎','💧','💧','🧘','🧘','⚡','⚡'];
        let selected = [];
        const grid = document.getElementById('memory-grid');
        emojis.sort(() => 0.5 - Math.random()).forEach(emoji => {
            const card = document.createElement('div'); card.className = 'memory-card'; card.dataset.val = emoji;
            card.onclick = () => {
                if(selected.length < 2 && !card.innerText) {
                    card.innerText = emoji; selected.push(card);
                    if(selected.length === 2) {
                        if(selected[0].dataset.val === selected[1].dataset.val) selected = [];
                        else setTimeout(() => { selected[0].innerText = ''; selected[1].innerText = ''; selected = []; }, 500);
                    }
                }
            };
            grid.appendChild(card);
        });

        // --- 5. ALARM CORE TIMER (DUAL-TAB SYNC READY) ---
        
        setInterval(() => {
            const now = new Date();
            const currentTime = now.getHours().toString().padStart(2, '0') + ":" + now.getMinutes().toString().padStart(2, '0');
            document.querySelectorAll('.habit-entry').forEach(habit => {
                if (currentTime === habit.getAttribute('data-time').substring(0, 5)) {
                    if(audioPermission) alarmAudio.play().catch(e => console.log("Locked by browser"));
                    document.getElementById('alarmTaskName').innerText = habit.getAttribute('data-name');
                    document.getElementById('alarmOverlay').style.display = 'flex';
                    if (Notification.permission === "granted" && navigator.serviceWorker.ready) {
                        navigator.serviceWorker.ready.then(reg => reg.active.postMessage({ type: 'TRIGGER_ALARM', habitName: habit.getAttribute('data-name'), userName: "<?php echo $user_name; ?>" }));
                    }
                }
            });
        }, 1000);

        // --- 6. CHARTS & UTILS ---
        new Chart(document.getElementById('weeklyChart').getContext('2d'), { type: 'bar', data: { labels: ['D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'Today'], datasets: [{ label: 'Steps', data: <?php echo json_encode($weekly_steps); ?>, backgroundColor: '#00d4ff' }] } });
        new Chart(document.getElementById('questChart').getContext('2d'), { type: 'radar', data: { labels: ['Water', 'Sleep', 'Steps', 'Yoga', 'Diet', 'Focus'], datasets: [{ data: [80, 60, 90, 40, 75, 85], backgroundColor: 'rgba(0, 212, 255, 0.2)', borderColor: '#00d4ff' }] } });

        function addNewHabitToDB() {
            const name = document.getElementById('habitName').value; const time = document.getElementById('habitTime').value;
            if(!name || !time) return alert("Fill data");
            fetch('save_habit.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `name=${encodeURIComponent(name)}&time=${time}` }).then(() => location.reload());
        }

        function claimHabitPoints(name, btn) { fetch('save_points.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `task_name=${encodeURIComponent(name)}&points=4` }).then(() => location.reload()); }

        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js?v=' + Date.now());
            navigator.serviceWorker.addEventListener('message', event => {
                if (event.data.type === 'STOP_AUDIO') stopAlarm();
                if (event.data.type === 'START_AUDIO_RELIABLE') { if(audioPermission) { alarmAudio.play(); document.getElementById('alarmOverlay').style.display = 'flex'; } }
            });
        }
        document.getElementById('alarmBtn').onclick = () => Notification.requestPermission();
    </script>
</body>
</html>
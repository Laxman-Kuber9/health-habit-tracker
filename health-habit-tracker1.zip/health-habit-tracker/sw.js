// Service Worker for HabitQuest - Ultimate Background Pro
// Developed by Team Junun 🚀

self.addEventListener('install', (event) => { self.skipWaiting(); });
self.addEventListener('activate', (event) => { event.waitUntil(clients.claim()); });

self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'TRIGGER_ALARM') {
        const options = {
            body: `Hi Laxman, it's time for: ${event.data.habitName}! 🚀`,
            icon: 'https://cdn-icons-png.flaticon.com/512/3105/3105807.png',
            badge: 'https://cdn-icons-png.flaticon.com/512/3105/3105807.png',
            // Aggressive Vibration pattern to wake you up!
            vibrate: [500, 110, 500, 110, 500, 110, 200, 110, 500, 110, 500],
            requireInteraction: true, 
            tag: 'habit-alarm-sync',
            renotify: true,
            data: { habit: event.data.habitName },
            actions: [
                { action: 'done', title: '✅ I DID THIS' },
                { action: 'stop', title: '🛑 STOP' }
            ]
        };

        // This triggers the SYSTEM NOTIFICATION SOUND even if screen is OFF
        event.waitUntil(self.registration.showNotification('⏰ HabitQuest Mega Alert!', options));
    }
});

self.addEventListener('notificationclick', (event) => {
    const notification = event.notification;
    const action = event.action;
    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clientList => {
            for (const client of clientList) {
                client.postMessage({ type: 'STOP_AUDIO', action: action, habit: notification.data.habit });
                if ('focus' in client) return client.focus();
            }
            if (clients.openWindow) return clients.openWindow('index.php');
        })
    );
    notification.close();
});
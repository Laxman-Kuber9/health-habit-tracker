<?php
session_start();
require 'db.php';

if(isset($_POST['id']) && isset($_SESSION['user_id'])) {
    $habit_id = $_POST['id'];
    $user_id = $_SESSION['user_id'];

    
    $stmt = $conn->prepare("DELETE FROM user_habits WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $habit_id, $user_id);
    
    if($stmt->execute()) {
        echo "Success";
    } else {
        echo "Error";
    }
}
?>
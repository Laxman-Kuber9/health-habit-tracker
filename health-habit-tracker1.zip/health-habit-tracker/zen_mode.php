<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zen Mode - HabitQuest</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;500;700&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: 'Poppins', sans-serif; 
            background: radial-gradient(circle at 50% 50%, #0b0f19 0%, #000000 100%); 
            color: #ffffff; 
            height: 100vh; 
            display: flex; 
            overflow: hidden; 
            flex-direction: row;
        }

        .glass { background: rgba(255, 255, 255, 0.02); backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 20px; }
        .neon-text-green { color: #00ffcc; text-shadow: 0 0 10px rgba(0, 255, 204, 0.6); font-family: 'Orbitron', sans-serif; }
        
        /* Sidebar Desktop */
        .sidebar { width: 260px; padding: 20px; display: flex; flex-direction: column; gap: 15px; z-index: 100; border-right: 1px solid rgba(255,255,255,0.05); }
        .logo { font-size: 22px; font-weight: 700; text-align: center; margin-bottom: 20px; font-family: 'Orbitron'; }
        .nav-item { padding: 12px 15px; border-radius: 12px; cursor: pointer; transition: 0.3s; display: flex; align-items: center; gap: 15px; font-weight: 500; color: #a0aec0; text-decoration: none; font-size: 14px; }
        .nav-item:hover, .nav-item.active { background: rgba(0, 212, 255, 0.1); color: #00d4ff; border-left: 4px solid #00d4ff; box-shadow: 0 0 15px rgba(0, 212, 255, 0.2); }

        .main-content { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 20px; }

        /* Breathing Animation */
        .breathe-container { position: relative; display: flex; align-items: center; justify-content: center; margin-bottom: 40px; }
        
        .breathe-circle {
            width: 220px; height: 220px; border-radius: 50%;
            background: radial-gradient(circle, rgba(0,212,255,0.4) 0%, rgba(0,255,204,0.1) 100%);
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; font-weight: bold; font-family: 'Orbitron', sans-serif;
            box-shadow: 0 0 50px rgba(0, 212, 255, 0.3);
            animation: breatheAction 10s infinite ease-in-out;
            border: 2px solid rgba(0, 255, 204, 0.3);
            z-index: 2;
        }

        .outer-glow {
            position: absolute; width: 220px; height: 220px; border-radius: 50%;
            background: rgba(0, 255, 204, 0.1);
            animation: glowPulse 10s infinite ease-in-out;
        }

        @keyframes breatheAction {
            0%, 100% { transform: scale(1); }
            40%, 60% { transform: scale(1.6); box-shadow: 0 0 100px rgba(0, 255, 204, 0.6); }
        }

        @keyframes glowPulse {
            0%, 100% { transform: scale(1.2); opacity: 0.2; }
            50% { transform: scale(2); opacity: 0.5; }
        }

        .instruction-text { font-size: 24px; color: #00ffcc; font-family: 'Orbitron'; letter-spacing: 4px; margin-top: 20px; height: 30px; }
        
        .zen-stats { margin-top: 40px; display: flex; gap: 30px; }
        .stat-box { padding: 15px 25px; text-align: center; }
        .stat-box h4 { font-size: 12px; color: #a0aec0; text-transform: uppercase; margin-bottom: 5px; }
        .stat-box p { font-size: 20px; font-family: 'Orbitron'; color: #00d4ff; }

        .audio-controls { margin-top: 30px; }
        .btn-zen { background: rgba(0, 212, 255, 0.1); border: 1px solid #00d4ff; color: #00d4ff; padding: 10px 20px; border-radius: 50px; cursor: pointer; font-family: 'Orbitron'; font-size: 12px; transition: 0.3s; }
        .btn-zen:hover { background: #00d4ff; color: #000; }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body { flex-direction: column; }
            .sidebar { 
                width: 100%; height: 70px; flex-direction: row; position: fixed; 
                bottom: 0; left: 0; top: auto; padding: 5px; border-top: 1px solid rgba(255,255,255,0.1);
                background: rgba(11, 15, 25, 0.95); border-radius: 20px 20px 0 0;
            }
            .sidebar .logo { display: none; }
            .nav-item { flex-direction: column; gap: 4px; font-size: 10px; flex: 1; justify-content: center; padding: 5px; border: none !important; }
            .nav-item i { font-size: 18px; }
            .main-content { padding-bottom: 100px; }
            .breathe-circle { width: 180px; height: 180px; font-size: 14px; }
            .instruction-text { font-size: 18px; }
        }
    </style>
</head>
<body>
    <div class="sidebar glass">
        <div class="logo neon-text-green"><i class="fa-solid fa-om"></i> ZEN</div>
        <a href="index.php" class="nav-item"><i class="fa-solid fa-house"></i> <span>Home</span></a>
        <a href="ai_scan.php" class="nav-item"><i class="fa-solid fa-camera"></i> <span>AI Scan</span></a>
        <a href="zen_mode.php" class="nav-item active"><i class="fa-solid fa-om"></i> <span>Zen</span></a>
        <a href="logout.php" class="nav-item" style="color: #ff4757;"><i class="fa-solid fa-power-off"></i> <span>Exit</span></a>
    </div>

    <div class="main-content">
        <div class="breathe-container">
            <div class="outer-glow"></div>
            <div class="breathe-circle" id="mainCircle">RELAX</div>
        </div>

        <div class="instruction-text" id="statusText">GET READY</div>

        <div class="zen-stats">
            <div class="stat-box glass">
                <h4>Focus Time</h4>
                <p id="timer">00:00</p>
            </div>
            <div class="stat-box glass">
                <h4>Mood</h4>
                <p>CALM</p>
            </div>
        </div>

        <div class="audio-controls">
            <button class="btn-zen" onclick="toggleAudio()"><i class="fa-solid fa-wind"></i> Play Nature Sound</button>
        </div>

        <audio id="zenAudio" loop src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"></audio>
    </div>

    <script>
        // 1. Timer Logic
        let seconds = 0;
        setInterval(() => {
            seconds++;
            let mins = Math.floor(seconds / 60).toString().padStart(2, '0');
            let secs = (seconds % 60).toString().padStart(2, '0');
            document.getElementById('timer').innerText = `${mins}:${secs}`;
        }, 1000);

        // 2. Dynamic Instruction Logic
        const statusText = document.getElementById('statusText');
        const mainCircle = document.getElementById('mainCircle');

        function updateInstructions() {
            setTimeout(() => { 
                statusText.innerText = "BREATHE IN"; 
                mainCircle.innerText = "INHALE";
            }, 0);
            
            setTimeout(() => { 
                statusText.innerText = "HOLD"; 
                mainCircle.innerText = "STAY";
            }, 4000);
            
            setTimeout(() => { 
                statusText.innerText = "BREATHE OUT"; 
                mainCircle.innerText = "EXHALE";
            }, 6000);
        }

        updateInstructions();
        setInterval(updateInstructions, 10000);

        // 3. Audio Control
        let isPlaying = false;
        function toggleAudio() {
            const audio = document.getElementById('zenAudio');
            const btn = document.querySelector('.btn-zen');
            if(!isPlaying) {
                audio.play();
                btn.innerHTML = '<i class="fa-solid fa-pause"></i> Mute Sound';
                isPlaying = true;
            } else {
                audio.pause();
                btn.innerHTML = '<i class="fa-solid fa-wind"></i> Play Nature Sound';
                isPlaying = false;
            }
        }
    </script>
</body>
</html>
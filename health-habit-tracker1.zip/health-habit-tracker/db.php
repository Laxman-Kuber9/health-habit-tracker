<?php
$host = "localhost"; 
$user = "User_Name"; 
$pass = "Database_Password"; 
$dbname = "Database_Name"; 


$conn = new mysqli($host, $user, $pass, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php
session_start();
require 'db.php';
if(isset($_POST['name']) && isset($_SESSION['user_id'])) {
    $name = $_POST['name'];
    $time = $_POST['time'];
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("INSERT INTO user_habits (user_id, habit_name, habit_time) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $name, $time);
    $stmt->execute();
    echo "Saved";
}
?>
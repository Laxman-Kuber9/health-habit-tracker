<?php
session_start();
require 'db.php';

$message = '';
$msg_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $new_pass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    // Check if email exists
    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $new_pass, $email);
        if ($stmt->execute()) {
            $message = "Password Reset Successful! <a href='login.php' style='color:#00ffcc;'>Login now</a>";
            $msg_type = 'success';
        }
    } else {
        $message = "Email not found in our Realm!";
        $msg_type = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - HabitQuest</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;500;700&display=swap');
        body { font-family: 'Poppins', sans-serif; background: radial-gradient(circle at 10% 20%, #0b0f19 0%, #1a1b41 100%); color: #fff; height: 100vh; display: flex; align-items: center; justify-content: center; }
        .panel { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(16px); padding: 30px; border-radius: 20px; border: 1px solid rgba(255, 255, 255, 0.08); width: 100%; max-width: 400px; text-align: center; }
        .neon { color: #00ffcc; font-family: 'Orbitron'; margin-bottom: 20px; display: block; }
        input { width: 100%; padding: 12px; background: rgba(0,0,0,0.3); border: 1px solid rgba(0,212,255,0.2); border-radius: 12px; color: #fff; margin-bottom: 15px; outline: none; }
        .btn { width: 100%; background: linear-gradient(45deg, #00d4ff, #00ffcc); border: none; padding: 12px; border-radius: 12px; font-weight: bold; cursor: pointer; font-family: 'Orbitron'; }
        .alert { padding: 10px; border-radius: 10px; margin-bottom: 15px; font-size: 13px; }
        .error { background: rgba(255, 71, 87, 0.1); color: #ff4757; border: 1px solid #ff4757; }
        .success { background: rgba(0, 255, 204, 0.1); color: #00ffcc; border: 1px solid #00ffcc; }
    </style>
</head>
<body>
    <div class="panel">
        <span class="neon">RECOVERY MODE</span>
        <?php if($message): ?>
            <div class="alert <?php echo $msg_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Registered Email" required>
            <input type="password" name="new_password" placeholder="Enter New Password" required>
            <button type="submit" class="btn">RESET PASSWORD</button>
        </form>
        <p style="margin-top:20px; font-size:12px;"><a href="login.php" style="color:#00d4ff; text-decoration:none;">Back to Login</a></p>
    </div>
</body>
</html>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Food Scan - HabitQuest</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;500;700&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: 'Poppins', sans-serif; 
            background: radial-gradient(circle at 10% 20%, #0b0f19 0%, #1a1b41 100%); 
            color: #ffffff; 
            min-height: 100vh; 
            display: flex; 
            overflow-x: hidden;
        }

        .glass { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 20px; }
        
        /* Sidebar Desktop */
        .sidebar { 
            width: 260px; padding: 20px; display: flex; flex-direction: column; gap: 20px; 
            background: rgba(255,255,255,0.03); backdrop-filter: blur(16px); 
            border-right: 1px solid rgba(255,255,255,0.05); z-index: 100;
        }
        .logo { font-size: 24px; font-weight: 700; text-align: center; margin-bottom: 30px; color: #00ffcc; font-family: 'Orbitron', sans-serif;}
        .nav-item { padding: 15px 20px; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 15px; color: #a0aec0; text-decoration: none; transition: 0.3s;}
        .nav-item:hover, .nav-item.active { background: rgba(0, 212, 255, 0.1); color: #00d4ff; border-left: 4px solid #00d4ff; }

        /* Main Content */
        .main-content { flex: 1; padding: 40px; display: flex; flex-direction: column; align-items: center; }
        
        .camera-container { 
            width: 100%; max-width: 500px; position: relative; 
            border-radius: 20px; overflow: hidden; border: 2px solid #00d4ff;
            background: #000; aspect-ratio: 4/3; margin-bottom: 20px;
        }

        video { width: 100%; height: 100%; object-fit: cover; }

        /* Scanning Animation Line */
        .scan-line {
            position: absolute; top: 0; left: 0; width: 100%; height: 4px;
            background: #00ffcc; box-shadow: 0 0 15px #00ffcc;
            z-index: 10; animation: scanMove 3s infinite linear;
            display: none; /* Shown during scanning */
        }
        @keyframes scanMove {
            0% { top: 0; }
            100% { top: 100%; }
        }

        .controls { display: flex; gap: 15px; margin-top: 20px; }
        
        .action-btn { 
            background: linear-gradient(45deg, #00d4ff, #00ffcc); border: none; 
            padding: 15px 30px; border-radius: 50px; color: #000; font-weight: bold; 
            cursor: pointer; font-size: 16px; transition: 0.3s; font-family: 'Orbitron';
        }
        .action-btn:hover { transform: scale(1.05); box-shadow: 0 0 20px rgba(0, 255, 204, 0.6); }
        .action-btn.secondary { background: rgba(255,255,255,0.1); color: #fff; border: 1px solid rgba(255,255,255,0.2); }

        /* Result Panel */
        #result-panel {
            width: 100%; max-width: 500px; margin-top: 20px; padding: 20px; display: none;
        }
        .data-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 15px; }
        .data-card { padding: 15px; text-align: center; background: rgba(0,0,0,0.2); border-radius: 12px; }
        .data-card h4 { font-size: 12px; color: #a0aec0; text-transform: uppercase; }
        .data-card p { font-size: 18px; color: #00ffcc; font-family: 'Orbitron'; }

        /* Mobile Responsive Navigation */
        @media (max-width: 768px) {
            body { flex-direction: column; }
            .sidebar { 
                width: 100%; height: 70px; flex-direction: row; position: fixed; 
                bottom: 0; left: 0; top: auto; padding: 5px; 
                background: rgba(11, 15, 25, 0.95); border-top: 1px solid rgba(255,255,255,0.1);
                border-radius: 20px 20px 0 0;
            }
            .sidebar .logo { display: none; }
            .nav-item { flex-direction: column; gap: 4px; font-size: 10px; flex: 1; justify-content: center; padding: 5px; border: none !important; }
            .nav-item i { font-size: 18px; }
            .main-content { padding: 20px; padding-bottom: 100px; }
            .action-btn { padding: 12px 20px; font-size: 14px; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo"><i class="fa-solid fa-gamepad"></i> HabitQuest</div>
        <a href="index.php" class="nav-item"><i class="fa-solid fa-house"></i> <span>Dashboard</span></a>
        <a href="ai_scan.php" class="nav-item active"><i class="fa-solid fa-camera"></i> <span>AI Scan</span></a>
        <a href="zen_mode.php" class="nav-item"><i class="fa-solid fa-om"></i> <span>Zen</span></a>
        <a href="logout.php" class="nav-item" style="color: #ff4757;"><i class="fa-solid fa-power-off"></i> <span>Logout</span></a>
    </div>

    <div class="main-content">
        <h2 style="font-family: 'Orbitron'; margin-bottom: 20px; color: #00ffcc;">Meal Scanner 1.0</h2>
        
        <div class="camera-container glass">
            <video id="video" autoplay playsinline></video>
            <div class="scan-line" id="scanLine"></div>
        </div>

        <div class="controls">
            <button class="action-btn" id="snapBtn" onclick="takeSnapshot()">SCAN MEAL</button>
            <button class="action-btn secondary" onclick="location.reload()">RE-SCAN</button>
        </div>

        <div id="result-panel" class="glass">
            <h3 style="font-family: 'Orbitron'; font-size: 16px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px;">
                <i class="fa-solid fa-microchip"></i> AI ANALYSIS COMPLETE
            </h3>
            <div class="data-grid">
                <div class="data-card">
                    <h4>Identified</h4>
                    <p>Protein Bowl</p>
                </div>
                <div class="data-card">
                    <h4>Calories</h4>
                    <p>420 kcal</p>
                </div>
                <div class="data-card">
                    <h4>Protein</h4>
                    <p>28g</p>
                </div>
                <div class="data-card">
                    <h4>Health Score</h4>
                    <p>92%</p>
                </div>
            </div>
            <p style="font-size: 11px; color: #a0aec0; margin-top: 15px; text-align: center;">
                Great choice, Laxman! This meal fits your fitness quest.
            </p>
        </div>
    </div>

    <script>
        const video = document.getElementById('video');
        const snapBtn = document.getElementById('snapBtn');
        const scanLine = document.getElementById('scanLine');
        const resultPanel = document.getElementById('result-panel');

        // 1. Access Camera
        async function startCamera() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { facingMode: "environment" }, 
                    audio: false 
                });
                video.srcObject = stream;
            } catch (err) {
                alert("Camera access denied! Please allow camera permissions.");
            }
        }

        // 2. Take Snapshot & Start Fake AI Scan
        function takeSnapshot() {
            // Show scanning animation
            scanLine.style.display = "block";
            snapBtn.innerText = "ANALYZING...";
            snapBtn.disabled = true;

            // Simulate AI Processing time (2 seconds)
            setTimeout(() => {
                scanLine.style.display = "none";
                snapBtn.innerText = "DONE ✅";
                resultPanel.style.display = "block";
                
                // Vibrate on completion
                if (navigator.vibrate) navigator.vibrate(200);
                
                // Scroll to result
                resultPanel.scrollIntoView({ behavior: 'smooth' });
            }, 2500);
        }

        // Start camera on load
        window.onload = startCamera;
    </script>
</body>
</html>
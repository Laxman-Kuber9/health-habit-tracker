<?php
session_start();
require 'db.php';

if(isset($_POST['points']) && isset($_SESSION['user_id'])) {
    $points = (int)$_POST['points'];
    $user_id = $_SESSION['user_id'];

    // Update coins in users table
    $stmt = $conn->prepare("UPDATE users SET total_coins = total_coins + ? WHERE id = ?");
    $stmt->bind_param("ii", $points, $user_id);
    
    if($stmt->execute()) {
        echo "Success";
    } else {
        echo "Error";
    }
}
?>